exports.test = ()=>{
    console.log('hello i am @ remote zip')
}