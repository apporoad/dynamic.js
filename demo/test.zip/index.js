exports.test = ()=>{
    console.log('hello i am @ local zip')
}